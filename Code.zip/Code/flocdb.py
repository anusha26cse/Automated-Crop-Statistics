# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'flocdb.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(3000, 3000)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        MainWindow.setFont(font)
        MainWindow.setStyleSheet("background-image:url(:/home/cropbg4.jpg)")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(220, 260, 211, 31))
        self.label.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.lineEdit = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit.setGeometry(QtCore.QRect(460, 180, 221, 33))
        self.lineEdit.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit.setObjectName("lineEdit")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_4.setGeometry(QtCore.QRect(710, 140, 221, 33))
        self.lineEdit_4.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_4.setObjectName("lineEdit_4")
        self.label_3 = QtWidgets.QLabel(self.centralwidget)
        self.label_3.setGeometry(QtCore.QRect(220, 300, 211, 31))
        self.label_3.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_3.setObjectName("label_3")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(460, 140, 211, 31))
        self.label_4.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_4.setObjectName("label_4")
        self.label_5 = QtWidgets.QLabel(self.centralwidget)
        self.label_5.setGeometry(QtCore.QRect(220, 220, 211, 31))
        self.label_5.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_5.setAlignment(QtCore.Qt.AlignCenter)
        self.label_5.setObjectName("label_5")
        self.label_6 = QtWidgets.QLabel(self.centralwidget)
        self.label_6.setGeometry(QtCore.QRect(220, 180, 211, 31))
        self.label_6.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_6.setAlignment(QtCore.Qt.AlignCenter)
        self.label_6.setObjectName("label_6")
        self.label_2 = QtWidgets.QLabel(self.centralwidget)
        self.label_2.setGeometry(QtCore.QRect(220, 340, 211, 31))
        self.label_2.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_2.setObjectName("label_2")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(310, 560, 371, 31))
        self.pushButton_2.setToolTip("")
        self.pushButton_2.setToolTipDuration(2)
        self.pushButton_2.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_2.setObjectName("pushButton_2")
        self.label_10 = QtWidgets.QLabel(self.centralwidget)
        self.label_10.setGeometry(QtCore.QRect(220, 460, 211, 31))
        self.label_10.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_10.setAlignment(QtCore.Qt.AlignCenter)
        self.label_10.setObjectName("label_10")
        self.label_11 = QtWidgets.QLabel(self.centralwidget)
        self.label_11.setGeometry(QtCore.QRect(220, 380, 211, 31))
        self.label_11.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_11.setAlignment(QtCore.Qt.AlignCenter)
        self.label_11.setObjectName("label_11")
        self.label_12 = QtWidgets.QLabel(self.centralwidget)
        self.label_12.setGeometry(QtCore.QRect(220, 420, 211, 31))
        self.label_12.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_12.setAlignment(QtCore.Qt.AlignCenter)
        self.label_12.setObjectName("label_12")
        self.lineEdit_8 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_8.setGeometry(QtCore.QRect(460, 220, 221, 33))
        self.lineEdit_8.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_8.setObjectName("lineEdit_8")
        self.lineEdit_11 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_11.setGeometry(QtCore.QRect(460, 260, 221, 33))
        self.lineEdit_11.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);\n"
"")
        self.lineEdit_11.setObjectName("lineEdit_11")
        self.lineEdit_14 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_14.setGeometry(QtCore.QRect(460, 300, 221, 33))
        self.lineEdit_14.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_14.setObjectName("lineEdit_14")
        self.lineEdit_17 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_17.setGeometry(QtCore.QRect(460, 340, 221, 33))
        self.lineEdit_17.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_17.setObjectName("lineEdit_17")
        self.lineEdit_20 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_20.setGeometry(QtCore.QRect(460, 380, 221, 33))
        self.lineEdit_20.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_20.setObjectName("lineEdit_20")
        self.lineEdit_23 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_23.setGeometry(QtCore.QRect(460, 420, 221, 33))
        self.lineEdit_23.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_23.setObjectName("lineEdit_23")
        self.lineEdit_26 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_26.setGeometry(QtCore.QRect(460, 460, 221, 33))
        self.lineEdit_26.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_26.setObjectName("lineEdit_26")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(590, 60, 241, 41))
        self.label_7.setStyleSheet("font: 75 20pt \"Calibri\";\n"
"color: rgb(255, 255, 0);\n"
"")
        self.label_7.setAlignment(QtCore.Qt.AlignCenter)
        self.label_7.setObjectName("label_7")
        self.label_8 = QtWidgets.QLabel(self.centralwidget)
        self.label_8.setGeometry(QtCore.QRect(710, 180, 211, 31))
        self.label_8.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_8.setAlignment(QtCore.Qt.AlignCenter)
        self.label_8.setObjectName("label_8")
        self.lineEdit_2 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_2.setGeometry(QtCore.QRect(950, 180, 221, 33))
        self.lineEdit_2.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_2.setObjectName("lineEdit_2")
        self.lineEdit_3 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_3.setGeometry(QtCore.QRect(950, 220, 221, 33))
        self.lineEdit_3.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_3.setObjectName("lineEdit_3")
        self.label_9 = QtWidgets.QLabel(self.centralwidget)
        self.label_9.setGeometry(QtCore.QRect(710, 220, 211, 31))
        self.label_9.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_9.setAlignment(QtCore.Qt.AlignCenter)
        self.label_9.setObjectName("label_9")
        self.lineEdit_5 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_5.setGeometry(QtCore.QRect(950, 300, 221, 33))
        self.lineEdit_5.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_5.setObjectName("lineEdit_5")
        self.lineEdit_6 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_6.setGeometry(QtCore.QRect(950, 260, 221, 33))
        self.lineEdit_6.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_6.setObjectName("lineEdit_6")
        self.label_13 = QtWidgets.QLabel(self.centralwidget)
        self.label_13.setGeometry(QtCore.QRect(710, 260, 211, 31))
        self.label_13.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_13.setAlignment(QtCore.Qt.AlignCenter)
        self.label_13.setObjectName("label_13")
        self.label_14 = QtWidgets.QLabel(self.centralwidget)
        self.label_14.setGeometry(QtCore.QRect(710, 300, 211, 31))
        self.label_14.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_14.setAlignment(QtCore.Qt.AlignCenter)
        self.label_14.setObjectName("label_14")
        self.lineEdit_7 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_7.setGeometry(QtCore.QRect(950, 380, 221, 33))
        self.lineEdit_7.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_7.setObjectName("lineEdit_7")
        self.lineEdit_9 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_9.setGeometry(QtCore.QRect(950, 340, 221, 33))
        self.lineEdit_9.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_9.setObjectName("lineEdit_9")
        self.label_15 = QtWidgets.QLabel(self.centralwidget)
        self.label_15.setGeometry(QtCore.QRect(710, 340, 211, 31))
        self.label_15.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_15.setAlignment(QtCore.Qt.AlignCenter)
        self.label_15.setObjectName("label_15")
        self.label_16 = QtWidgets.QLabel(self.centralwidget)
        self.label_16.setGeometry(QtCore.QRect(710, 380, 211, 31))
        self.label_16.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_16.setAlignment(QtCore.Qt.AlignCenter)
        self.label_16.setObjectName("label_16")
        self.lineEdit_10 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_10.setGeometry(QtCore.QRect(950, 460, 221, 33))
        self.lineEdit_10.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_10.setObjectName("lineEdit_10")
        self.lineEdit_12 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_12.setGeometry(QtCore.QRect(950, 420, 221, 33))
        self.lineEdit_12.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_12.setObjectName("lineEdit_12")
        self.label_17 = QtWidgets.QLabel(self.centralwidget)
        self.label_17.setGeometry(QtCore.QRect(710, 420, 211, 31))
        self.label_17.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_17.setAlignment(QtCore.Qt.AlignCenter)
        self.label_17.setObjectName("label_17")
        self.label_18 = QtWidgets.QLabel(self.centralwidget)
        self.label_18.setGeometry(QtCore.QRect(710, 460, 211, 31))
        self.label_18.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_18.setAlignment(QtCore.Qt.AlignCenter)
        self.label_18.setObjectName("label_18")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(710, 560, 371, 31))
        self.pushButton_3.setToolTip("")
        self.pushButton_3.setToolTipDuration(2)
        self.pushButton_3.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_3.setObjectName("pushButton_3")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "File locations"))
        self.label.setText(_translate("MainWindow", "Name of the color File 3"))
        self.lineEdit_4.setToolTip(_translate("MainWindow", "<html><head/><body><p><br/></p></body></html>"))
        self.lineEdit_4.setWhatsThis(_translate("MainWindow", "<html><head/><body><p><br/></p></body></html>"))
        self.label_3.setText(_translate("MainWindow", "Name of the color File 4"))
        self.label_4.setText(_translate("MainWindow", "Name of the Map File"))
        self.label_5.setText(_translate("MainWindow", "Name of the color File 2"))
        self.label_6.setText(_translate("MainWindow", "Name of the color File 1"))
        self.label_2.setText(_translate("MainWindow", "Name of the color File 5"))
        self.pushButton_2.setText(_translate("MainWindow", "Enter Details into Database"))
        self.label_10.setText(_translate("MainWindow", "Name of the color File 8"))
        self.label_11.setText(_translate("MainWindow", "Name of the color File 6"))
        self.label_12.setText(_translate("MainWindow", "Name of the color File 7"))
        self.label_7.setText(_translate("MainWindow", "Enter all File Locations"))
        self.label_8.setText(_translate("MainWindow", "Name of the Crop 1"))
        self.label_9.setText(_translate("MainWindow", "Name of the Crop 2"))
        self.label_13.setText(_translate("MainWindow", "Name of the Crop 3"))
        self.label_14.setText(_translate("MainWindow", "Name of the Crop 4"))
        self.label_15.setText(_translate("MainWindow", "Name of the Crop 5"))
        self.label_16.setText(_translate("MainWindow", "Name of the Crop 6"))
        self.label_17.setText(_translate("MainWindow", "Name of the Crop 7"))
        self.label_18.setText(_translate("MainWindow", "Name of the Crop 8"))
        self.pushButton_3.setText(_translate("MainWindow", "Go Back to Home Page"))

import image_rc
