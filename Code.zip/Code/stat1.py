import sys
import os
from PIL import Image
from stat2 import *
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QMessageBox
import sqlite3
con = sqlite3.connect('ctss1')
class MyForm(QtWidgets.QMainWindow):
  def __init__(self,parent=None):
    QtWidgets.QWidget.__init__(self,parent)
    self.ui=Ui_MainWindow()
    self.ui.setupUi(self)
    self.ui.pushButton_5.clicked.connect(self.pixcalc)
    self.ui.pushButton_6.clicked.connect(self.perccalc) 
    self.ui.pushButton_7.clicked.connect(self.areacalc)
  def pixcalc(self):
      with con:
            msg = QMessageBox()
            msg.setText("Calculating Pixel Values!!")
            msg.setWindowTitle("Status")
            msg.setWindowIcon(QtGui.QIcon("black tic.png"))
            msg.setIcon(QMessageBox.Information)
            msg.setStyleSheet("background-color: rgb(0, 0, 0);")
            msg.setStyleSheet("text-color: rgb(255, 255, 255);")
            msg.exec_()
            cur = con.cursor()
            fname= str(self.ui.lineEdit_4.text())
            print(fname)
            cur.execute('SELECT * from floc where fname=?',(fname,))
            result= cur.fetchone()
            fname=result[0];
            clr1=result[1];
            cname1=result[2];
            clr2=result[3];
            cname2=result[4];
            clr3=result[5];
            cname3=result[6];
            clr4=result[7];
            cname4=result[8];
            clr5=result[9];
            cname5=result[10];
            clr6=result[11];
            cname6=result[12];
            clr7=result[13];
            cname7=result[14];
            clr8=result[15];
            cname8=result[16];
            im = Image.open(clr1) 
            colors = im.getcolors(250)
            max_occurence, most_present1 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present1) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr2) 
            colors = im.getcolors(250) 
            max_occurence, most_present2 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present2) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr3) 
            colors = im.getcolors(250) 
            max_occurence, most_present3 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present3) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr4)
            colors = im.getcolors(250)
            max_occurence, most_present4 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present4) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr5)
            colors = im.getcolors(250) 
            max_occurence, most_present5 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present5) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr6)
            colors = im.getcolors(250)
            max_occurence, most_present6 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present6) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr7) 
            colors = im.getcolors(250)
            max_occurence, most_present7 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present7) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr8)
            colors = im.getcolors(250) 
            max_occurence, most_present8 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present8) = c        
            except TypeError:
              raise Exception("Too many colors in the image")
            im1 = Image.open(fname)
            clr1 = 0
            clr2 = 0
            clr3 = 0
            clr4 = 0
            clr5 = 0
            clr6 = 0
            clr7 = 0
            othr1 = 0
            for pixel in im1.getdata(): 
                pixel1 = pixel[:3]
                if (pixel1 == most_present1[:3]):
                    clr1 += 1 
                elif (pixel1 == most_present2[:3]): 
                    clr2 += 1
                elif (pixel1 == most_present3[:3]): 
                    clr3 += 1
                elif (pixel1 == most_present4[:3]): 
                    clr4 += 1
                elif (pixel1 == most_present5[:3]): 
                    clr5 += 1
                elif (pixel1 == most_present6[:3]): 
                    clr6 += 1
                elif (pixel1 == most_present7[:3]): 
                    clr7 += 1
                elif (pixel1 == most_present8[:3]): 
                    othr1 += 1
            print('-----------------------------------------------------------')
            print('Pixel areas of different crops in the map are as follows :')
            print('-----------------------------------------------------------')
            print(cname1+' = ' + str(clr1)+'\n'+cname2+' = ' + str(clr2)+'\n'+cname3+' = ' + str(clr3)+'\n'+cname4+' = ' + str(clr4)+'\n'+cname5+' = '+ str(clr5)+'\n'+cname6+' = ' + str(clr6)+'\n'+cname7+' = ' + str(clr7)+'\n'+cname8+' = '+str(othr1))
            print('-----------------------------------------------------------')
  def areacalc(self):
      with con:
            msg = QMessageBox()
            msg.setText("Calculating Areas!!")
            msg.setWindowTitle("Status")
            msg.setWindowIcon(QtGui.QIcon("black tic.png"))
            msg.setIcon(QMessageBox.Information)
            msg.setStyleSheet("background-color: rgb(0, 0, 0);")
            msg.setStyleSheet("text-color: rgb(255, 255, 255);")
            msg.exec_()
            cur = con.cursor()
            fname= str(self.ui.lineEdit_4.text())
            print(fname)
            cur.execute('SELECT * from floc where fname=?',(fname,))
            result= cur.fetchone()
            fname=result[0];
            clr1=result[1];
            cname1=result[2];
            clr2=result[3];
            cname2=result[4];
            clr3=result[5];
            cname3=result[6];
            clr4=result[7];
            cname4=result[8];
            clr5=result[9];
            cname5=result[10];
            clr6=result[11];
            cname6=result[12];
            clr7=result[13];
            cname7=result[14];
            clr8=result[15];
            cname8=result[16];
            im = Image.open(clr1) 
            colors = im.getcolors(250) 
            max_occurence, most_present1 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present1) = c
            except TypeError:
              raise Exception("Too many colors in the image")
            im = Image.open(clr2) 
            colors = im.getcolors(250) 
            max_occurence, most_present2 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present2) = c
                  #print(most_present2[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr3) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present3 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present3) = c
                  #print(most_present3[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr4) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present4 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present4) = c
                  #print(most_present4[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr5) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present5 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present5) = c
                  #print(most_present5[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr6) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present6 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present6) = c
                  #print(most_present6[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr7) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present7 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present7) = c
                  #print(most_present7[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr8) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present8 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present8) = c
                  #print(most_present8[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im1 = Image.open(fname)
            clr1 = 0
            clr2 = 0
            clr3 = 0
            clr4 = 0
            clr5 = 0
            clr6 = 0
            clr7 = 0
            othr1 = 0
            for pixel in im1.getdata(): 
                pixel1 = pixel[:3]
                if (pixel1 == most_present1[:3]): # if your image is RGB (if RGBA, (0, 0, 0, 255) or so
                    clr1 += 1 
                elif (pixel1 == most_present2[:3]): 
                    clr2 += 1
                elif (pixel1 == most_present3[:3]): 
                    clr3 += 1
                elif (pixel1 == most_present4[:3]): 
                    clr4 += 1
                elif (pixel1 == most_present5[:3]): 
                    clr5 += 1
                elif (pixel1 == most_present6[:3]): 
                    clr6 += 1
                elif (pixel1 == most_present7[:3]): 
                    clr7 += 1
                elif (pixel1 == most_present8[:3]): 
                    othr1 += 1
            clr1 = (clr1/1428.0)*10000
            clr2 = (clr2/1428.0)*10000
            clr3 = (clr3/1428.0)*10000
            clr4 = (clr4/1428.0)*10000
            clr5 = (clr5/1428.0)*10000
            clr6 = (clr6/1428.0)*10000
            clr7 = (clr7/1428.0)*10000
            othr1 = (othr1/1428)*10000
            print('---------------------------------------------------------------')
            print('Areas of different crops,in sq.km, in the map are as follows :')
            print('---------------------------------------------------------------')
            #print('Maize = ' + str(othr1)+'\n'+'Orchard = ' + str(clr2)+'\n'+'Shelter Forest = ' + str(clr3)+'\n'+'Leek = ' + str(clr4)+'\n'+'Lettuce = '+ str(clr5)+'\n'+'Cauliflower = ' + str(clr6)+'\n'+'Potato = ' + str(clr7)+'\n'+'Watermelon = '+str(clr1))
            print(cname1+' = ' + str(clr1)+'\n'+cname2+' = ' + str(clr2)+'\n'+cname3+' = ' + str(clr3)+'\n'+cname4+' = ' + str(clr4)+'\n'+cname5+' = '+ str(clr5)+'\n'+cname6+' = ' + str(clr6)+'\n'+cname7+' = ' + str(clr7)+'\n'+cname8+' = '+str(othr1))
            print('-----------------------------------------------------------')
  def perccalc(self):
      with con:
            msg = QMessageBox()
            msg.setText("Calculating Percentages!!")
            msg.setWindowTitle("Status")
            msg.setWindowIcon(QtGui.QIcon("black tic.png"))
            msg.setIcon(QMessageBox.Information)
            msg.setStyleSheet("background-color: rgb(0, 0, 0);")
            msg.setStyleSheet("text-color: rgb(255, 255, 255);")
            msg.exec_()
            cur = con.cursor()
            fname= str(self.ui.lineEdit_4.text())
            print(fname)
            cur.execute('SELECT * from floc where fname=?',(fname,))
            #cur.execute('SELECT * from floc')
            result= cur.fetchone()
            fname=result[0];
            clr1=result[1];
            cname1=result[2];
            clr2=result[3];
            cname2=result[4];
            clr3=result[5];
            cname3=result[6];
            clr4=result[7];
            cname4=result[8];
            clr5=result[9];
            cname5=result[10];
            clr6=result[11];
            cname6=result[12];
            clr7=result[13];
            cname7=result[14];
            clr8=result[15];
            cname8=result[16];
            im = Image.open(clr1) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present1 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present1) = c
                  #print(most_present1[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr2) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present2 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present2) = c
                  #print(most_present2[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr3) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present3 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present3) = c
                  #print(most_present3[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr4) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present4 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present4) = c
                  #print(most_present4[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr5) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present5 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present5) = c
                  #print(most_present5[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr6) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present6 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present6) = c
                  #print(most_present6[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr7) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present7 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present7) = c
                  #print(most_present7[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im = Image.open(clr8) # Can be many different formats.
            colors = im.getcolors(250) #put a higher value if there are many colors in your image
            max_occurence, most_present8 = 0, 0
            try:
              for c in colors:
                if c[0] > max_occurence:
                  (max_occurence, most_present8) = c
                  #print(most_present8[:3])
             
            except TypeError:
              raise Exception("Too many colors in the image")
            
            im1 = Image.open(fname)
            clr1 = 0
            clr2 = 0
            clr3 = 0
            clr4 = 0
            clr5 = 0
            clr6 = 0
            clr7 = 0
            clr = 0
            othr1 = 0
            for pixel in im1.getdata(): 
                pixel1 = pixel[:3]
                if (pixel1 == most_present1[:3]): # if your image is RGB (if RGBA, (0, 0, 0, 255) or so
                    clr1 += 1 
                elif (pixel1 == most_present2[:3]): 
                    clr2 += 1
                elif (pixel1 == most_present3[:3]): 
                    clr3 += 1
                elif (pixel1 == most_present4[:3]): 
                    clr4 += 1
                elif (pixel1 == most_present5[:3]): 
                    clr5 += 1
                elif (pixel1 == most_present6[:3]): 
                    clr6 += 1
                elif (pixel1 == most_present7[:3]): 
                    clr7 += 1
                elif (pixel1 == most_present8[:3]): 
                    othr1 += 1
            clr1 = (clr1/1428.0)*10000
            clr2 = (clr2/1428.0)*10000
            clr3 = (clr3/1428.0)*10000
            clr4 = (clr4/1428.0)*10000
            clr5 = (clr5/1428.0)*10000
            clr6 = (clr6/1428.0)*10000
            clr7 = (clr7/1428.0)*10000
            othr1 = (othr1/1428.0)*10000
            ta=clr1+clr2+clr3+clr4+clr5+clr6+clr7+othr1
            clr1 = (clr1/ta)*100
            clr2 = (clr2/ta)*100
            clr3 = (clr3/ta)*100
            clr4 = (clr4/ta)*100
            clr5 = (clr5/ta)*100
            clr6 = (clr6/ta)*100
            clr7 = (clr7/ta)*100
            othr1 = (othr1/ta)*100
            print('---------------------------------------------------------------')
            print('Areas of different crops,in percentages, in the map are as follows :')
            print('---------------------------------------------------------------')
            #print('Maize = ' + str(othr1)+'\n'+'Orchard = ' + str(clr2)+'\n'+'Shelter Forest = ' + str(clr3)+'\n'+'Leek = ' + str(clr4)+'\n'+'Lettuce = '+ str(clr5)+'\n'+'Cauliflower = ' + str(clr6)+'\n'+'Potato = ' + str(clr7)+'\n'+'Watermelon = '+str(clr1))
            print(cname1+' = ' + str(clr1)+'\n'+cname2+' = ' + str(clr2)+'\n'+cname3+' = ' + str(clr3)+'\n'+cname4+' = ' + str(clr4)+'\n'+cname5+' = '+ str(clr5)+'\n'+cname6+' = ' + str(clr6)+'\n'+cname7+' = ' + str(clr7)+'\n'+cname8+' = '+str(othr1))
            print('-----------------------------------------------------------')
            try:
                cur.execute('INSERT INTO perc VALUES(?,?,?,?,?,?,?,?,?)',(fname,clr1,clr2,clr3,clr4,clr5,clr6,clr7,othr1))
            except:
                print("Data already stored in database")
                print('-----------------------------------------------------------')

if __name__ == "__main__":
  app = QtWidgets.QApplication(sys.argv)
  myapp=MyForm()
  myapp.show()
  sys.exit(app.exec_())