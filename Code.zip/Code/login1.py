#This program gets two values from a DB into lineEdits.
import sys
import os
from login import *
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QMessageBox

import sqlite3
con = sqlite3.connect('ctss1')

#import MySQLdb as mdb
#con = mdb.connect('localhost', 'team1', 'test623', 'ctss1'); 

class MyForm(QtWidgets.QMainWindow):
  def __init__(self,parent=None):
    QtWidgets.QWidget.__init__(self,parent)
    self.ui = Ui_MainWindow()
    self.ui.setupUi(self)
    self.ui.pushButton.clicked.connect(self.validate) 

  
      
  def validate(self):
    with con:
      cur = con.cursor()
      uname= str(self.ui.lineEdit.text())
      pwd = str(self.ui.lineEdit_2.text())
      if(uname=="admin" and pwd=="Mini@123"):
        msg = QMessageBox()
        msg.setText("Login Successful")
        msg.setWindowTitle("Status")
        msg.setWindowIcon(QtGui.QIcon("black tic.png"))
        msg.setIcon(QMessageBox.Information)
        msg.setStyleSheet("background-color: rgb(0, 0, 0);")
        msg.setStyleSheet("text-color: rgb(255, 255, 255);")
        msg.exec_()
        os.system("python home1.py")
      else:
        msg = QMessageBox()
        msg.setText("Invalid username or password")
        msg.setWindowTitle("Status")
        msg.setWindowIcon(QtGui.QIcon("black tic.png"))
        msg.setIcon(QMessageBox.Information)
        msg.setStyleSheet("background-color: rgb(0, 0, 0);")
        msg.setStyleSheet("text-color: rgb(255, 255, 255);")
        msg.exec_()

if __name__ == "__main__":
  app = QtWidgets.QApplication(sys.argv)
  myapp = MyForm()
  myapp.show()
  sys.exit(app.exec_())
