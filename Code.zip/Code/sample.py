from reportlab.lib import colors
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter, inch
from reportlab.lib.pagesizes import landscape
from reportlab.platypus import Image
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle,Paragraph
from reportlab.lib.styles import getSampleStyleSheet


data=[['cname1','1'],['cname2','2'],['cname3','3'],['cname4','4'],['cname5','5'],['cname6','6'],['cname7','7'],['cname8','8']]
data.sort(key=lambda x:x[1],reverse=True)


pdf_name="s2.pdf"



fname="crop3.png"
pdf_name=fname[:-4]+".pdf"
c=canvas.Canvas(pdf_name,pagesize=letter)
c.drawImage("icon1.jpg",10,680,width=100,height=100)
c.setFont('Helvetica',28,leading=None)
c.drawCentredString(300,700,'Crop Statistics(in percentage)')
c.setFont('Helvetica',18,leading=None)
c.drawCentredString(220,650,'File Name : '+fname)
c.drawImage(fname,100,300,width=400,height=300)


aH=250
aW=350
'''for i in l:
    result2=i[0]+"       "+i[1]
    c.setFont('Helvetica',16,leading=None)
    c.drawCentredString(h,w,result2)
    w-=18'''
t=Table(data)
t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.25, colors.black),
                       ('INNERGRID', (0, 0), (-1, -1), 0.25, colors.black)]))
data_len = len(data)
for each in range(data_len):
    if each % 2 == 0:
        bg_color = colors.whitesmoke
    else:
        bg_color = colors.lightgrey

    t.setStyle(TableStyle([('BACKGROUND', (0, each), (-1, each), bg_color)]))
styles = getSampleStyleSheet()
style = styles["BodyText"]
header = Paragraph("<bold><font size=18>Crop Stat Report</font></bold>", style)
w, h = header.wrap(aW, aH)
header.drawOn(c, 100, aH)
aH = aH - h
w, h = t.wrap(aW, aH)
t.drawOn(c, 275, aH-h)
c.showPage()
print("Writing")
c.save()