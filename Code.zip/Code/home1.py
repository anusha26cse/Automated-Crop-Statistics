#This program gets two values from a DB into lineEdits.
import sys
import os
from home import *
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QMessageBox

import sqlite3
con = sqlite3.connect('ctss1')
class MyForm(QtWidgets.QMainWindow):
  def __init__(self,parent=None):
    QtWidgets.QWidget.__init__(self,parent)
    self.ui = Ui_MainWindow()
    self.ui.setupUi(self)
    self.ui.pushButton_2.clicked.connect(self.aboutus)
    self.ui.pushButton_3.clicked.connect(self.sdb) 
    self.ui.pushButton_4.clicked.connect(self.stat)


  def aboutus(self):
      msg = QMessageBox()
      msg.setText("Redirecting to Report Generation!!")
      msg.setWindowTitle("Status")
      msg.setWindowIcon(QtGui.QIcon("black tic.png"))
      msg.setIcon(QMessageBox.Information)
      msg.setStyleSheet("background-color: rgb(0, 0, 0);")
      msg.setStyleSheet("text-color: rgb(255, 255, 255);")
      msg.exec_()
      os.system("python report1.py")
  def sdb(self):
      #QMessageBox.information(self, "Status", "Redirecting to Store Details page") 
      msg = QMessageBox()
      msg.setText("Redirecting to Store Details page!!")
      msg.setWindowTitle("Status")
      msg.setWindowIcon(QtGui.QIcon("black tic.png"))
      msg.setIcon(QMessageBox.Information)
      msg.setStyleSheet("background-color: rgb(0, 0, 0);")
      msg.setStyleSheet("text-color: rgb(255, 255, 255);")
      msg.exec_()
      os.system("python flocdb1.py")

  def stat(self):
      #QMessageBox.information(self, "Status", "Redirecting to Analyse Statistics page") 
      msg = QMessageBox()
      msg.setText("Redirecting to Analyse Statistics page!!")
      msg.setWindowTitle("Status")
      msg.setWindowIcon(QtGui.QIcon("black tic.png"))
      msg.setIcon(QMessageBox.Information)
      msg.setStyleSheet("background-color: rgb(0, 0, 0);")
      msg.setStyleSheet("text-color: rgb(255, 255, 255);")
      msg.exec_()
      os.system("python stat1.py")

if __name__ == "__main__":
  app = QtWidgets.QApplication(sys.argv)
  myapp = MyForm()
  myapp.show()
  sys.exit(app.exec_())
