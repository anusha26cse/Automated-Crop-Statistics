#This program gets two values from a DB into lineEdits.
import sys
import os
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle,Paragraph
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.lib.pagesizes import landscape
from reportlab.platypus import Image
from report import *
from PyQt5 import QtWidgets, QtGui, QtCore
from reportlab import platypus
from reportlab.lib.styles import ParagraphStyle as PS
from reportlab.platypus import SimpleDocTemplate
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet
import sqlite3
from PyQt5.QtWidgets import QMessageBox
con = sqlite3.connect('ctss1')

#import MySQLdb as mdb
#con = mdb.connect('localhost', 'team1', 'test623', 'ctss1'); 

class MyForm(QtWidgets.QMainWindow):
  def __init__(self,parent=None):
    QtWidgets.QWidget.__init__(self,parent)
    self.ui = Ui_MainWindow()
    self.ui.setupUi(self)
    self.ui.pushButton_5.clicked.connect(self.validate)
     


  def validate(self):
      with con:
          cur = con.cursor()
          fname= str(self.ui.lineEdit_4.text())
          cur.execute('SELECT * from floc where fname=?',(fname,))
          result= cur.fetchone()
          fname=result[0];
          cname1=result[2];
          cname2=result[4];
          cname3=result[6];
          cname4=result[8];
          cname5=result[10];
          cname6=result[12];
          cname7=result[14];
          cname8=result[16];
          result2 = str(" ")
          cur.execute('SELECT * from perc where fname=?',(fname,))
          result= cur.fetchone()
          per1=result[1]
          per2=result[2]
          per3=result[3]
          per4=result[4]
          per5=result[5]
          per6=result[6]
          per7=result[7]
          per8=result[8]
          data=[['CROP NAME','AREA(in %)'],[cname1,per1],[cname2,per2],[cname3,per3],[cname4,per4],[cname5,per5],[cname6,per6],[cname7,per7],[cname8,per8]]
          data.sort(key=lambda x:x[1],reverse=True)
          '''result2=result2+str("Statistics of various crops(in percentages) in the given Map")+"<br/><br/>"
          result2 = result2+str("File Name : ")+str(fname)+ "<br/><br/>"
          for i in l:
              result2=result2+str(i[0])+"<br/>"+str(i[1])+"<br/><br/>"
          result2=result2+str(l[-1][0])+str(" should be grown more in order to eliminate the crisis")+"<br/><br/>"
          pdf_name=fname[:-4]+".pdf"
          items = []
          items.append(platypus.Paragraph(result2,PS('body')))
          doc = SimpleDocTemplate(pdf_name)
          doc.multiBuild(items)'''
          pdf_name=fname[:-4]+".pdf"
          c=canvas.Canvas(pdf_name,pagesize=letter)
          c.drawImage("icon1.jpg",10,680,width=100,height=100)
          c.setFont('Helvetica',28,leading=None)
          c.drawCentredString(300,700,'Crop Statistics(in percentage)')
          c.setFont('Helvetica',18,leading=None)
          c.drawCentredString(220,650,'File Name : '+fname)
          c.drawImage(fname,100,300,width=400,height=300)
          aH=250
          aW=350
          t=Table(data)
          t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.4, colors.black),
                       ('INNERGRID', (0, 0), (-1, -1), 0.4, colors.black)]))
          data_len = len(data)
          for each in range(data_len):
              if each % 2 == 0:
                  bg_color = colors.whitesmoke
              else:
                  bg_color = colors.lightgrey

              t.setStyle(TableStyle([('BACKGROUND', (0, each), (-1, each), bg_color)]))
          styles = getSampleStyleSheet()
          style = styles["BodyText"]
          header = Paragraph("<bold><font size=18>Crop Stat Report</font></bold>", style)
          w, h = header.wrap(aW, aH)
          header.drawOn(c, 100, aH)
          aH = aH - h
          w, h = t.wrap(aW, aH)
          t.drawOn(c, 275, aH-h)
          c.showPage()
          #QMessageBox.information(self, "Status", "Report is generated")
          msg = QMessageBox()
          msg.setText("Report is generated")
          msg.setWindowTitle("Status")
          msg.setWindowIcon(QtGui.QIcon("black tic.png"))
          msg.setIcon(QMessageBox.Information)
          msg.setStyleSheet("background-color: rgb(0, 0, 0);")
          msg.setStyleSheet("text-color: rgb(255, 255, 255);")
          msg.exec_()
          print("Writing")
          c.save()
if __name__ == "__main__":
  app = QtWidgets.QApplication(sys.argv)
  myapp = MyForm()
  myapp.show()
  sys.exit(app.exec_())
