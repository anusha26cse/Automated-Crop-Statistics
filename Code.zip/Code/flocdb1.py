#This program gets two values from a DB into lineEdits.
import sys
import os
from flocdb import *
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QMessageBox

import sqlite3
con = sqlite3.connect('ctss1')
class MyForm(QtWidgets.QMainWindow):
  def __init__(self,parent=None):
     QtWidgets.QWidget.__init__(self,parent)
     self.ui = Ui_MainWindow()
     self.ui.setupUi(self)
     self.ui.pushButton_3.clicked.connect(self.home)
     self.ui.pushButton_2.clicked.connect(self.insertvalues)

  def home(self):
    #QMessageBox.about(self, "Status", "Redirecting to Home page")
    msg = QMessageBox()
    msg.setText("Redirecting to Home page")
    msg.setWindowTitle("Status")
    msg.setWindowIcon(QtGui.QIcon("black tic.png"))
    msg.setIcon(QMessageBox.Information)
    msg.setStyleSheet("background-color: rgb(0, 0, 0);")
    msg.setStyleSheet("text-color: rgb(255, 255, 255);")
    msg.exec_()
    os.system("python home1.py")

  def insertvalues(self):
    with con:
      cur = con.cursor()
      fname = str(self.ui.lineEdit_4.text())
      
      clr1 = str(self.ui.lineEdit.text())
      cname1=str(self.ui.lineEdit_2.text())
      
      clr2 = str(self.ui.lineEdit_8.text())
      cname2=str(self.ui.lineEdit_3.text())
      
      clr3 = str(self.ui.lineEdit_11.text())
      cname3=str(self.ui.lineEdit_6.text())
      
      clr4 = str(self.ui.lineEdit_14.text())
      cname4=str(self.ui.lineEdit_5.text())
      
      clr5 = str(self.ui.lineEdit_17.text())
      cname5=str(self.ui.lineEdit_9.text())
      
      clr6 = str(self.ui.lineEdit_20.text())
      cname6=str(self.ui.lineEdit_7.text())
      
      clr7 = str(self.ui.lineEdit_23.text())
      cname7=str(self.ui.lineEdit_12.text())
      
      clr8 = str(self.ui.lineEdit_26.text())
      cname8=str(self.ui.lineEdit_10.text())
      if fname!="" and clr1!="" and cname1!="" and clr2!="" and cname2!="" and clr3!="" and cname3!="" and clr4!="" and cname4!="" and clr5!="" and cname5!="" and clr6!="" and cname6!="" and clr7!="" and cname7!="" and clr8!="" and cname8!="":
          cur.execute('INSERT INTO floc VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(fname,clr1,cname1,clr2,cname2,clr3,cname3,clr4,cname4,clr5,cname5,clr6,cname6,clr7,cname7,clr8,cname8))
          con.commit()
          #QMessageBox.information(self, "Status", "Data is entered successfully!!")
          msg = QMessageBox()
          msg.setText("Data is entered successfully!!")
          msg.setWindowTitle("Status")
          msg.setWindowIcon(QtGui.QIcon("black tic.png"))
          msg.setIcon(QMessageBox.Information)
          msg.setStyleSheet("background-color: rgb(0, 0, 0);")
          msg.setStyleSheet("text-color: rgb(255, 255, 255);")
          msg.exec_()
      else:
          #QMessageBox.informationt(self, "Status", "All fields are mandataory!!")
          msg = QMessageBox()
          msg.setText("All fields are mandataory!!")
          msg.setWindowTitle("Status")
          msg.setWindowIcon(QtGui.QIcon("black tic.png"))
          msg.setIcon(QMessageBox.Information)
          msg.setStyleSheet("background-color: rgb(0, 0, 0);")
          msg.setStyleSheet("text-color: rgb(255, 255, 255);")
          msg.exec_()
          print("All values are needed")

if __name__ == "__main__":  
    app = QtWidgets.QApplication(sys.argv)
    myapp = MyForm()
    myapp.show()
    sys.exit(app.exec_())
