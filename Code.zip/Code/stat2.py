# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'stat2.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(3000, 3000)
        MainWindow.setStyleSheet("background:url(:/home/cropbg4.jpg)")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton_5 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_5.setGeometry(QtCore.QRect(350, 440, 121, 31))
        self.pushButton_5.setToolTip("")
        self.pushButton_5.setToolTipDuration(2)
        self.pushButton_5.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_5.setObjectName("pushButton_5")
        self.pushButton_6 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_6.setGeometry(QtCore.QRect(600, 440, 121, 31))
        self.pushButton_6.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_6.setObjectName("pushButton_6")
        self.label_7 = QtWidgets.QLabel(self.centralwidget)
        self.label_7.setGeometry(QtCore.QRect(450, 140, 381, 41))
        self.label_7.setStyleSheet("font: 75 20pt \"Calibri\";\n"
"color: rgb(255, 255, 0);\n"
"")
        self.label_7.setAlignment(QtCore.Qt.AlignCenter)
        self.label_7.setObjectName("label_7")
        self.label_4 = QtWidgets.QLabel(self.centralwidget)
        self.label_4.setGeometry(QtCore.QRect(410, 310, 211, 31))
        self.label_4.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.label_4.setAlignment(QtCore.Qt.AlignCenter)
        self.label_4.setObjectName("label_4")
        self.pushButton_7 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_7.setGeometry(QtCore.QRect(830, 440, 121, 31))
        self.pushButton_7.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_7.setObjectName("pushButton_7")
        self.lineEdit_4 = QtWidgets.QLineEdit(self.centralwidget)
        self.lineEdit_4.setGeometry(QtCore.QRect(690, 310, 221, 33))
        self.lineEdit_4.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.lineEdit_4.setAlignment(QtCore.Qt.AlignCenter)
        self.lineEdit_4.setObjectName("lineEdit_4")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Analyse Statistics"))
        self.pushButton_5.setText(_translate("MainWindow", "Pixels"))
        self.pushButton_6.setText(_translate("MainWindow", "Percentages"))
        self.label_7.setText(_translate("MainWindow", "Analyse Statistics"))
        self.label_4.setText(_translate("MainWindow", "Name of the Map File"))
        self.pushButton_7.setText(_translate("MainWindow", "Area"))
        self.lineEdit_4.setToolTip(_translate("MainWindow", "<html><head/><body><p><br/></p></body></html>"))
        self.lineEdit_4.setWhatsThis(_translate("MainWindow", "<html><head/><body><p><br/></p></body></html>"))

import image_rc
