# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'home.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(3000, 3000)
        font = QtGui.QFont()
        font.setBold(True)
        font.setWeight(75)
        MainWindow.setFont(font)
        MainWindow.setStyleSheet("background:url(:/home/cropbg4.jpg)")
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.pushButton_2 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_2.setGeometry(QtCore.QRect(460, 290, 301, 41))
        self.pushButton_2.setToolTip("")
        self.pushButton_2.setToolTipDuration(2)
        self.pushButton_2.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_2.setObjectName("pushButton_2")
        self.pushButton_3 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_3.setGeometry(QtCore.QRect(460, 350, 301, 41))
        self.pushButton_3.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_3.setObjectName("pushButton_3")
        self.pushButton_4 = QtWidgets.QPushButton(self.centralwidget)
        self.pushButton_4.setGeometry(QtCore.QRect(460, 410, 301, 41))
        self.pushButton_4.setStyleSheet("font: 75 16pt \"Calibri\";\n"
"color: rgb(255, 255, 0);")
        self.pushButton_4.setObjectName("pushButton_4")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(0, 0, 981, 231))
        self.label.setStyleSheet("background:url(:/home/cropbg4.jpg);\n"
"font: 75 50pt \"Calibri\";\n"
"color:rgb(255, 255, 127)")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        MainWindow.setCentralWidget(self.centralwidget)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Home Page"))
        self.pushButton_2.setText(_translate("MainWindow", "Report Generation"))
        self.pushButton_3.setText(_translate("MainWindow", "Store Details"))
        self.pushButton_4.setText(_translate("MainWindow", "Analyse Statistics"))
        self.label.setText(_translate("MainWindow", "Welcome to Automated Crop Stats"))

import image_rc
