from reportlab.lib import colors
from reportlab.lib.pagesizes import letter, inch
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle
 
doc = SimpleDocTemplate("simple_table_grid.pdf", pagesize=letter)
# container for the 'Flowable' objects
elements = []
l=[['cname1','1'],['cname2','2'],['cname3','3'],['cname4','4'],['cname5','5'],['cname6','6'],['cname7','7'],['cname8','8']]
l.sort(key=lambda x:x[1],reverse=True)
data=[] 
for i in l:
    data.append(i)
t=Table(data,2*[1*inch], 8*[0.5*inch])
t.setStyle(TableStyle([('ALIGN',(1,1),(-2,-2),'CENTER'),
                       ('TEXTCOLOR',(1,1),(-2,-2),colors.red),
                       ('VALIGN',(0,0),(0,-1),'MIDDLE'),
                       ('TEXTCOLOR',(0,0),(0,-1),colors.blue),
                       ('ALIGN',(0,-1),(-1,-1),'CENTER'),
                       ('VALIGN',(0,-1),(-1,-1),'MIDDLE'),
                       ('TEXTCOLOR',(0,-1),(-1,-1),colors.green),
                       ('INNERGRID', (0,0), (-1,-1), 0.25, colors.black),
                       ('BOX', (0,0), (-1,-1), 0.25, colors.black),
                       ]))
 
elements.append(t)
# write the document to disk
doc.build(elements)